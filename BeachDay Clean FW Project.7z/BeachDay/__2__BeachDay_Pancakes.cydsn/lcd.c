/* ========================================
 *
 * Copyright YOUR COMPANY, THE YEAR
 * All Rights Reserved
 * UNPUBLISHED, LICENSED SOFTWARE.
 *
 * CONFIDENTIAL AND PROPRIETARY INFORMATION
 * WHICH IS THE PROPERTY OF your company.
 *
 * ========================================
*/

#include "main.h"

#define STRDEF(s)       s, sizeof(s)

// example character
//  {0b11111,
//   0b00001,
//   0b00010,
//   0b00100,
//   0b01000,
//   0b10000,
//   0b10000}

void printChar(char ch, uint16_t col, uint16_t row, uint32_t color)
{
    uint32_t i, j, c;
    
    for(i = 0; i < 7; i++)
    {
        c = GetChar((uint8)ch, i);
        
        for(j = 0; j < 5; j++)
        {
            if(c & (1 << j))
            {
                gfx_drawPixel(col + (4-j), row + i, color);
            }
        }
    }
}

void printLine(char* str, uint8_t len, uint16_t x, uint16_t y, uint32_t color)
{
    uint32_t i;
    
    for(i = 0; i < len; i++)
    {
        if((x > DISPLAYWIDTH) || (y > DISPLAYHEIGHT))
        {
            return;
        }
        
        printChar(*str++, x + (i * 8), y, color);
    }
}

void ServLCD( void )
{
    printLine(STRDEF("Press [ENTER] to"), 10, 10,WHITE);
    printLine(STRDEF("Return to app."), 10, 20,WHITE);
}




/* [] END OF FILE */
