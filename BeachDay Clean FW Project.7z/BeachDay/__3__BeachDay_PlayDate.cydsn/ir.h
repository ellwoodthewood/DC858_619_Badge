/* ========================================
 *
 * Copyright YOUR COMPANY, THE YEAR
 * All Rights Reserved
 * UNPUBLISHED, LICENSED SOFTWARE.
 *
 * CONFIDENTIAL AND PROPRIETARY INFORMATION
 * WHICH IS THE PROPERTY OF your company.
 *
 * ========================================
*/

#ifndef IR_H
#define IR_H

#include "beachday.h"
    
#define IR_CODE_DELAY               MS(250)
    
enum {
    IR_ST_OFF = 0,
    IR_ST_RUN,
    IR_ST_IDLE,
    IR_ST_COUNT
};
    
void InitIR( void );
uint32_t GetIRCode( void );
uint32_t ServIR( void );
void EnableIR( void );
void DisableIR( void );


#endif

/* [] END OF FILE */
