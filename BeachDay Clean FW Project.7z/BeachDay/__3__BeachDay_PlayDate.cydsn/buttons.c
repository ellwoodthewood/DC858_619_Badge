/* ========================================
 *
 * Copyright YOUR COMPANY, THE YEAR
 * All Rights Reserved
 * UNPUBLISHED, LICENSED SOFTWARE.
 *
 * CONFIDENTIAL AND PROPRIETARY INFORMATION
 * WHICH IS THE PROPERTY OF your company.
 *
 * ========================================
*/

#include "beachday.h"

#define DEBOUNCE_DELAY      MS(50)

#define BTN_ENTER_RD    ((Enter_Read() == GPIO_LOW) ? TRUE : FALSE)
#define BTN_UP_RD       ((Up_Read() == GPIO_LOW) ? TRUE : FALSE)
#define BTN_DOWN_RD     ((Down_Read() == GPIO_LOW) ? TRUE : FALSE)
#define BTN_LEFT_RD     ((Left_Read() == GPIO_LOW) ? TRUE : FALSE)
#define BTN_RIGHT_RD    ((Right_Read() == GPIO_LOW) ? TRUE : FALSE)

uint32_t ButtonPressed[BTN_COUNT] = { 0 };

uint32_t ServButtons( void )
{
    static uint32_t st[BTN_COUNT] = { BTN_ST_INIT, BTN_ST_INIT, BTN_ST_INIT, BTN_ST_INIT, BTN_ST_INIT };
    static uint32_t Stamp[BTN_COUNT] = { 0 };
    static uint32_t PriorState[BTN_COUNT] = { BTN_RELEASED, BTN_RELEASED, BTN_RELEASED, BTN_RELEASED, BTN_RELEASED };
    uint32_t ButtonState[BTN_COUNT] = { BTN_ENTER_RD, BTN_UP_RD, BTN_DOWN_RD, BTN_LEFT_RD, BTN_RIGHT_RD };
    static uint32_t Debounce[BTN_COUNT] = { 0 };
    uint32_t i = 0;
    
    for(i = 0; i < BTN_COUNT; i++)
    {
        switch(st[i])
        {
            case BTN_ST_INIT:
                if(!ButtonState[i]) // if the button is not depressed, go to steady
                {
                    Debounce[i] = DEBOUNCE_DELAY;
                    PriorState[i] = ButtonState[i];
                    Stamp[i] = 0;
                    st[i] = BTN_ST_STEADY;
                }
                break;
            case BTN_ST_DEBOUNCE:
                if(ButtonState[i] != PriorState[i])
                {
                    Debounce[i] = DEBOUNCE_DELAY;
                }
                else
                {
                    DECTOZ(Debounce[i]);
                }
                
                if(Debounce[i] == 0)
                {
                    st[i] = BTN_ST_STEADY;
                }
                break;
            case BTN_ST_STEADY:
                if(ButtonState[i] != PriorState[i])
                {
                    if(PriorState[i] == BTN_DEPRESSED)
                    {
                        st[i] = BTN_ST_RELEASED;
                    }
                    else
                    {
                        Stamp[i] = GetTick();
                        st[i] = BTN_ST_DEBOUNCE;
                    }
                }

                break;
            case BTN_ST_RELEASED:
                ButtonPressed[i] = GetTick() - Stamp[i];
                Debounce[i] = DEBOUNCE_DELAY;
                st[i] = BTN_ST_DEBOUNCE;
                break;
            default:
                break;
        }
    }
    
    for(i = 0; i < BTN_COUNT; i++)
    {
        PriorState[i] = ButtonState[i];
    }
    
    for(i = 0; i < BTN_COUNT; i++)
    {
        if(st[i] == BTN_ST_DEBOUNCE)
        {
            return BTN_ST_DEBOUNCE;
        }
    }
    
    return BTN_ST_STEADY;
}

uint32_t PressOccured( uint32_t id )
{
    uint32_t PressDuration = ButtonPressed[id];
    ButtonPressed[id] = 0;
    
    return PressDuration;
}

/* [] END OF FILE */
