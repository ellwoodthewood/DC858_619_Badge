/* ========================================
 *
 * Copyright YOUR COMPANY, THE YEAR
 * All Rights Reserved
 * UNPUBLISHED, LICENSED SOFTWARE.
 *
 * CONFIDENTIAL AND PROPRIETARY INFORMATION
 * WHICH IS THE PROPERTY OF your company.
 *
 * ========================================
*/

#include "beachday.h"

int32_t ProxState = FALSE;

int32_t GetCSProxState( void )
{
    
    return ProxState;
}

uint32_t ServCS( void )
{
    uint32_t SomethingActive = FALSE;
    
    if(CapSense_NOT_BUSY == CapSense_IsBusy())
    {
        CapSense_ProcessAllWidgets();
        if (CapSense_IsAnyWidgetActive())
        {
            if(CapSense_IsProximitySensorActive(CapSense_PROXIMITY0_WDGT_ID, CapSense_PROXIMITY0_SNS0_ID))
            {
                ProxState = TRUE;
            }
            else
            {
                ProxState = FALSE;
            }
        }
        else
        {
            ProxState = FALSE;
        }

        CapSense_ScanAllWidgets();
    }
    
    return SomethingActive;
}


/* [] END OF FILE */
