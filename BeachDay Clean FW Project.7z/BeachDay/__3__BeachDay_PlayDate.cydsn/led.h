/* ========================================
 *
 * Copyright YOUR COMPANY, THE YEAR
 * All Rights Reserved
 * UNPUBLISHED, LICENSED SOFTWARE.
 *
 * CONFIDENTIAL AND PROPRIETARY INFORMATION
 * WHICH IS THE PROPERTY OF your company.
 *
 * ========================================
*/
#ifndef LED_H
#define LED_H

#include "beachday.h"


#define LED_COUNT   (WS2812B_LED_COUNT)
    
enum {
    LED_MODE_OFF = 0,
    LED_MODE_STATE,
    LED_MODE_VALUE,
    LED_MODE_ADC_SENSOR,
    LED_MODE_ADC_ANIMATION,
    LED_MODE_ADC_BATTERY,
    LED_MODE_CODE_COUNT,
    LED_MODE_INPUT_DISPLAY,
    LED_MODE_GLOBAL,
    LED_MODE_CUSTOM,
    LED_MODE_IDLE,
    LED_MODE_COUNT
};

typedef struct LED_PATTERN_t {
    void* cfg;
    uint8_t duty;       // in perc
    uint16_t period;    // in ms

} LED_PATTERN;


uint32_t ServLED( void );
void RequestLEDMode( uint32_t mode);
void SetGlobalLED( LED_PATTERN pat );
void SetCustomLED( LED_PATTERN pat, uint32_t id );

#endif

/* [] END OF FILE */
