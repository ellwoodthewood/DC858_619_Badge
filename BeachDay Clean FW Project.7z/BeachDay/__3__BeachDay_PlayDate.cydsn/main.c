/* ========================================
 *
 * Copyright YOUR COMPANY, THE YEAR
 * All Rights Reserved
 * UNPUBLISHED, LICENSED SOFTWARE.
 *
 * CONFIDENTIAL AND PROPRIETARY INFORMATION
 * WHICH IS THE PROPERTY OF your company.
 *
 * ========================================
*/

#include "beachday.h"

uint32_t MainTick = 0; // 48-day cycle (2^32 / TICK_FREQ) = 48.6 days
uint32_t State[ST_COUNT] = { 0 }, Mode = SYS_MODE_INPUT;

CY_ISR(Tick_Interrupt)
{
    TIMER_ClearInterrupt(TIMER_INTR_MASK_TC);
    // TIMER_ClearInterrupt(TIMER_INTR_MASK_CC_MATCH);
    
    /* Indicate that timer is raised to the main loop */
    MainTick++;
}

uint32_t GetTick( void )
{
    
    return MainTick;
}

uint32_t GetState( uint32_t id )
{
    if(id < ST_COUNT)
    {
        return State[id];
    }
    
    return 0;
}

int main(void)
{
    CyGlobalIntEnable; /* Enable global interrupts. */
    
    #ifdef CY_BLE_CYBLE_H
        /* For GCC compiler use separate API to initialize BLE Stack SRAM.
         * This is required for code sharing.
         */
        #if !defined(__ARMCC_VERSION)
            InitializeBootloaderSRAM();
        #endif
        
        /* Checks if Self Project Image is updated and Runs for the First time */
        AfterImageUpdate();
    #endif
    
    /* Place your initialization/startup code here (e.g. MyInst_Start()) */
    
    isrTimer_StartEx(Tick_Interrupt);
    TIMER_Start();
    
    InitIR();
    
    SPI_Start();
    
    ADC_Start();
    ADC_StartConvert();
    
    CapSense_Start();
    CapSense_ScanAllWidgets();
    
    uint32_t i; i = 0; i = i;
    for(;;)
    {
        switch(Mode)
        {
            default:
            case SYS_MODE_INPUT:
                SetGlobalLED( (LED_PATTERN){ WS2812B_GetCFG(WS2812B_CFG_BLUE), 50, TICK_FREQ} );
                RequestLEDMode(LED_MODE_INPUT_DISPLAY);
                DisableIR();
                DisableMQ303();
                break;
            case SYS_MODE_MQ303:
                EnableMQ303();
                DisableIR();
                RequestLEDMode(LED_MODE_ADC_SENSOR);
                break;
            case SYS_MODE_BATTERY:
                RequestLEDMode(LED_MODE_ADC_BATTERY);
                DisableIR();
                DisableMQ303();
                break;
            case SYS_MODE_DISPLAY:
                RequestLEDMode(LED_MODE_ADC_ANIMATION);
                DisableIR();
                DisableMQ303();
                break;
            case SYS_MODE_TVBGONE:
                RequestLEDMode(LED_MODE_CODE_COUNT);
                EnableIR();
                DisableMQ303();
                break;
        }
        
        State[SYS] = Mode;
        State[BTN] = ServButtons();
        State[CS] = ServCS();
        State[ADC] = ServADC();
        State[IR] = ServIR();
        State[LED] = ServLED();
        State[SSD1306] = ServSSD1306();
        State[LCD] = ServLCD();
        State[MQ303] = ServMQ303(GetADC(ADC_CH_SENSOR));
        State[WS2812B] = ServWS2812B();
        
        if(PressOccured(BTN_LEFT))
        {
            if(GetState(SYS) > 0)
            {
                RequestMode(GetState(SYS) - 1);
            }
            else
            {
                RequestMode(SYS_MODE_COUNT - 1);
            }
        }
        
        if(PressOccured(BTN_RIGHT))
        {
            if(GetState(SYS) < SYS_MODE_COUNT - 1)
            {
                RequestMode(GetState(SYS) + 1);
            }
            else
            {
                RequestMode(0);
            }
        }
        
#ifdef CY_BLE_CYBLE_H
        if((PressOccured(BTN_ENTER)) && (GetState(SYS) == SYS_MODE_SYSTEM))
        {
            JumpToBootloader();
        }
#endif
        
        CySysPmSleep();
        
        /* Place your application code here. */
    }
}

void RequestMode( uint32_t req )
{
    if(req < SYS_MODE_COUNT)
    {
        Mode = req;
    }
}

void JumpToBootloader( void )
{
    #ifdef CY_BLE_CYBLE_H
        Bootloadable_SetActiveApplication(0);
        Bootloadable_Load();
        CySoftwareReset();
    #endif
}


/* [] END OF FILE */
