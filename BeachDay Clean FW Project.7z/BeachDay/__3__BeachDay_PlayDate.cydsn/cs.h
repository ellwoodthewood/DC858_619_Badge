/* ========================================
 *
 * Copyright YOUR COMPANY, THE YEAR
 * All Rights Reserved
 * UNPUBLISHED, LICENSED SOFTWARE.
 *
 * CONFIDENTIAL AND PROPRIETARY INFORMATION
 * WHICH IS THE PROPERTY OF your company.
 *
 * ========================================
*/

#ifndef CS_H
#define CS_H

#include "beachday.h"

int32_t GetCSProxState( void );
uint32_t ServCS( void );

    
#endif

/* [] END OF FILE */
