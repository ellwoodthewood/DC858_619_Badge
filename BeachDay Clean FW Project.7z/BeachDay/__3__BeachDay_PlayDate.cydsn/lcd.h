/* ========================================
 *
 * Copyright YOUR COMPANY, THE YEAR
 * All Rights Reserved
 * UNPUBLISHED, LICENSED SOFTWARE.
 *
 * CONFIDENTIAL AND PROPRIETARY INFORMATION
 * WHICH IS THE PROPERTY OF your company.
 *
 * ========================================
*/

#ifndef LCD_H
#define LCD_H

#include "beachday.h"
    
enum {
    LCD_ST_INIT = 0,
    LCD_ST_IDLE,
    LCD_ST_COUNT
};

uint32_t ServLCD( void );
    
    
#endif

/* [] END OF FILE */
