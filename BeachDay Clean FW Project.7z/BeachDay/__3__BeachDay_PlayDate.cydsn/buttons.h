/* ========================================
 *
 * Copyright YOUR COMPANY, THE YEAR
 * All Rights Reserved
 * UNPUBLISHED, LICENSED SOFTWARE.
 *
 * CONFIDENTIAL AND PROPRIETARY INFORMATION
 * WHICH IS THE PROPERTY OF your company.
 *
 * ========================================
*/

#ifndef BUTTONS_H
#define BUTTONS_H
    
#include "beachday.h"

enum {
    BTN_DEPRESSED = 0,
    BTN_RELEASED
};
    
enum {
    BTN_ENTER = 0,
    BTN_UP,
    BTN_DOWN,
    BTN_LEFT,
    BTN_RIGHT,
    BTN_COUNT
};

enum {
    BTN_ST_INIT = 0,
    BTN_ST_DEBOUNCE,
    BTN_ST_STEADY,
    BTN_ST_RELEASED,
    BTN_ST_COUNT
};

void WaitForRelease( void );
uint32_t PressOccured( uint32_t id );
uint32_t ServButtons( void );

#endif

/* [] END OF FILE */
