/* ========================================
 *
 * Copyright YOUR COMPANY, THE YEAR
 * All Rights Reserved
 * UNPUBLISHED, LICENSED SOFTWARE.
 *
 * CONFIDENTIAL AND PROPRIETARY INFORMATION
 * WHICH IS THE PROPERTY OF your company.
 *
 * ========================================
*/

#ifndef MQ303_H
#define MQ303_H

#include "beachday.h"

enum {
    MQ303_ST_DISABLED = 0,
    MQ303_ST_INIT,
    MQ303_ST_HEAT_HV,
    MQ303_ST_HEAT_LV,
    MQ303_ST_MAINT,
    MQ303_ST_IDLE,
    MQ303_ST_SHDN,
    MQ303_ST_COUNT
};

uint32_t ServMQ303( uint32_t value );
uint32_t GetMQ303( void );
void EnableMQ303( void );
void DisableMQ303( void );


#endif

/* [] END OF FILE */
