/* ========================================
 *
 * Copyright YOUR COMPANY, THE YEAR
 * All Rights Reserved
 * UNPUBLISHED, LICENSED SOFTWARE.
 *
 * CONFIDENTIAL AND PROPRIETARY INFORMATION
 * WHICH IS THE PROPERTY OF your company.
 *
 * ========================================
*/

#ifndef IRCODE_H
#define IRCODE_H

#include "beachday.h"

struct IrCode {
    uint16_t duration;
    uint8_t pairs;
    uint8_t bits;
    uint16_t const *times;
    uint8_t codes[];
};

#define NA_CODES
// #define EU_CODES
#define IR_FREQ   (12000000u)

#define freq_to_timerval(f) (IR_FREQ / f)
#define NUM_ELEM(x) (sizeof (x) / sizeof (*(x)));
    
const struct IrCode * const * GetNACodes( void );
const struct IrCode * const * GetEUCodes( void );
uint8_t GetNACodeCount( void );
uint8_t GetEUCodeCount( void );
    
    
#endif

/* [] END OF FILE */
