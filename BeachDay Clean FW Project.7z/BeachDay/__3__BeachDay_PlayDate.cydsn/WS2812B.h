    /* ========================================
 *
 * Copyright YOUR COMPANY, THE YEAR
 * All Rights Reserved
 * UNPUBLISHED, LICENSED SOFTWARE.
 *
 * CONFIDENTIAL AND PROPRIETARY INFORMATION
 * WHICH IS THE PROPERTY OF your company.
 *
 * ========================================
*/

#ifndef WS2812B_H
#define WS2812B_H

#include "beachday.h"

enum {
    WS2812B_ST_DISABLED = 0,
    WS2812B_ST_INIT,
    WS2812B_ST_PREFIX,
    WS2812B_ST_WRITE,
    WS2812B_ST_SUFFIX,
    WS2812B_ST_IDLE,
    WS2812B_ST_SHDN,
    WS2812B_ST_COUNT
};

#define WS2812B_LED_COUNT   17
    
typedef struct WS2812B_CONFIG_t {
    uint8_t id;
    uint8_t red;
    uint8_t green;
    uint8_t blue;
} WS2812B_CONFIG;

enum {
    WS2812B_OFF = 0,
    WS2812B_LOW,
    WS2812B_MED,
    WS2812B_HIGH
};

enum {
    WS2812B_CFG_OFF = 0,
    WS2812B_CFG_RED,
    WS2812B_CFG_GREEN,
    WS2812B_CFG_BLUE,
    WS2812B_CFG_YELLOW,
    WS2812B_CFG_MAGENTA,
    WS2812B_CFG_CYAN,
    WS2812B_CFG_WHITE,
    WS2812B_CFG_COUNT
};

#define WS2812B_IS_BUSY     ((GetState(WS2812B) != WS2812B_ST_IDLE) ? TRUE : FALSE)

WS2812B_CONFIG* WS2812B_GetCFG( uint32 id );
void SetWS2812B( uint32_t id, uint32_t cfg );
uint32_t ServWS2812B( void );

#endif

/* [] END OF FILE */
