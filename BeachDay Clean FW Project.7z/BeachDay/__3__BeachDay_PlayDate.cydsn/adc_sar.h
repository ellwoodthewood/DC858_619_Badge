/* ========================================
 *
 * Copyright YOUR COMPANY, THE YEAR
 * All Rights Reserved
 * UNPUBLISHED, LICENSED SOFTWARE.
 *
 * CONFIDENTIAL AND PROPRIETARY INFORMATION
 * WHICH IS THE PROPERTY OF your company.
 *
 * ========================================
*/

#ifndef ADC_SAR_H
#define ADC_SAR_H
    
#include "cytypes.h"
    
enum {
    ADC_CH_BATTERY = 0,
    ADC_CH_SENSOR,
    ADC_CH_SUPPLY,
    ADC_CH_COUNT
};

uint32_t ServADC( void );
uint32_t GetADC( uint32_t ch );
    
    
#endif


/* [] END OF FILE */
