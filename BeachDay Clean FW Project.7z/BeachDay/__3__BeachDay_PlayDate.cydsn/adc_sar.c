 /* ========================================
 *
 * Copyright YOUR COMPANY, THE YEAR
 * All Rights Reserved
 * UNPUBLISHED, LICENSED SOFTWARE.
 *
 * CONFIDENTIAL AND PROPRIETARY INFORMATION
 * WHICH IS THE PROPERTY OF your company.
 *
 * ========================================
*/

#include "beachday.h"

// module definitions
uint32_t mvADC[ADC_CH_COUNT] = { 0 };

// module loop
uint32_t ServADC( void )
{
    static uint32_t st = 0;
    
#define ADC_DEPTH     4096
#define ADC_REF_MV    2048
#define ADC_TO_MV(ch) ((ADC_REF_MV * ((uint32_t)ADC_GetResult16(ch) + (ADC_DEPTH >> 1))) / ADC_DEPTH)
    
    if(ADC_IsEndConversion(ADC_RETURN_STATUS))
    {
        // get MV, then double due to dividers
        mvADC[ADC_CH_BATTERY] = (ADC_TO_MV(ADC_CH_BATTERY) * 2 * 1585) / 1000;
        
        // returns as est. content (ppm)
        mvADC[ADC_CH_SENSOR] = ADC_TO_MV(ADC_CH_SENSOR);
        
        // get MV, then double due to divider
        mvADC[ADC_CH_SUPPLY] = (ADC_TO_MV(ADC_CH_SUPPLY) * 1604) / 604; // 1MEG over 604K divider
    }
    
    return st;
}

// module functions
uint32_t GetADC( uint32_t ch )
{
    
    return (ch < ADC_CH_COUNT) ? mvADC[ch] : 0;
}

/* [] END OF FILE */
