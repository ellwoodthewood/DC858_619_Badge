/* ========================================
 *
 * Copyright YOUR COMPANY, THE YEAR
 * All Rights Reserved
 * UNPUBLISHED, LICENSED SOFTWARE.
 *
 * CONFIDENTIAL AND PROPRIETARY INFORMATION
 * WHICH IS THE PROPERTY OF your company.
 *
 * ========================================
*/


#ifndef BEACHDAY_H
#define BEACHDAY_H

#include "project.h"
    
#include "adc_sar.h"
#include "buttons.h"
#include "MQ303.h"
#include "WS2812B.h"
#include "led.h"
#include "buttons.h"
#include "cs.h"
#include "ir.h"
#include "ircode.h"
#include "lcd.h"
#include "font.h"
#include "SSD1306.h"
#ifdef CY_BLE_CYBLE_H
    #include "ota_mandatory.h"
#endif
    
#define FW_MAJ  0
#define FW_MIN  0
#define FW_LOC  0

#define TICK_FREQ       1000
#define SYS_FREQ_MHz    24
#define SYS_VCC         3300
    
#define TRUE        (1u)
#define FALSE       (0u)
#define GPIO_HIGH   (1u)
#define GPIO_LOW    (0u)

#define DECTOZ(a)                   do { if(a > 0) a--; } while(0)
#define DBG_PRINT_TEXT(...)   // omit superfluous debug from cypress libs
#define DBG_PRINTF(...)       // omit superfluous debug from cypress libs
#define MS(a)                       ((a * TICK_FREQ) / 1000)
#define MASK(a)                     (0x1 << a)

enum {
    ADC = 0,
    BTN,
    LED,
    CS,
    IR,
    LCD,
    MQ303,
    WS2812B,
    SSD1306,
    SYS,
    ST_COUNT
};

enum {
    SYS_MODE_INPUT = 0,
    SYS_MODE_MQ303,
    SYS_MODE_BATTERY,
    SYS_MODE_DISPLAY,
    SYS_MODE_TVBGONE,
#ifdef CY_BLE_CYBLE_H
    SYS_MODE_SYSTEM,
#endif
    SYS_MODE_COUNT
};

// MQ303A sensor configuration
#define MQ303_TYPE_ISO  0
#define MQ303_TYPE_H    1
#define MQ303_TYPE_ETH  2

#define MQ303_SELECTED_TYPE     MQ303_TYPE_ETH
    
#define MQ303_SUPPLY             3300 // mV
#define MQ303_PULLUPVAL         10000 // Ohms
    
// main functions for other modules
uint32_t GetTick( void );
uint32_t GetState( uint32_t id );
void RequestMode( uint32_t req );
void JumpToBootloader( void );

#endif

/* [] END OF FILE */
